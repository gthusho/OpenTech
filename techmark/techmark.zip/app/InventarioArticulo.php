<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InventarioArticulo extends Model
{
    protected $table = 'existencia_articulo';
}
