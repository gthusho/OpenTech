<?php
/*
    * rutas Cliente y Proveedor
    */
Route::resource('cliente','ClienteController');
