    <div class="row">
        <div class="col-sm-12">

            <h4 class="page-title">{{$brand['page']}}</h4>
            <ol class="breadcrumb">
                <li>
                    <a href="{{$brand['first'][0]}}">{{$brand['first'][1]}}</a>
                </li>
                <li>
                    <a href="{{$brand['second'][0]}}">{{$brand['second'][1]}}</a>
                </li>
                <li class="active">
                    {{$brand['page']}}
                </li>
            </ol>
        </div>
    </div>