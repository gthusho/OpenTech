<fieldset class="scheduler-border">
    <legend class="scheduler-border">OPERACIONES</legend>

    <br>
    <div class="form-group">
        <button type="submit" class="btn btn-inverse waves-effect waves-light  btn-sm "  id="AddItemCart"><i class=" icon-basket"></i>  Agregar</button>

    </div>
    <br>
    <div class="form-group">
        <span class="btn btn-inverse waves-effect waves-light  btn-sm "  id="ClearItemCart"><i class=" ti-brush-alt"></i>  Limpiar</span>
    </div>

</fieldset>