<div class="form-group col-lg-12">
    {!! Form::label('Razón Social/ Nombre (*) ')!!}
    {!! Form::text('razon_social',null,['class'=>'form-control','required'])!!}
</div>

<div class="form-group col-lg-6">
    {!! Form::label('Nit/CI (*)')!!}
    {!! Form::text('nit',null,['class'=>'form-control','required'])!!}
</div>
<div class="form-group col-lg-6">
    {!! Form::label('Teléfono')!!}
    {!! Form::text('telefono',null,['class'=>'form-control'])!!}
</div>
<div class="form-group col-lg-6">
    {!! Form::label('Celular')!!}
    {!! Form::text('celular',null,['class'=>'form-control'])!!}
</div>
<div class="form-group col-lg-6">
    {!! Form::label('Email')!!}
    {!! Form::text('email',null,['class'=>'form-control'])!!}
</div>
<div class="form-group col-lg-6">
    {!! Form::label('Fax')!!}
    {!! Form::text('fax',null,['class'=>'form-control'])!!}
</div>
<div class="form-group col-lg-6">
    {!! Form::label('Dirección')!!}
    {!! Form::text('direccion',null,['class'=>'form-control'])!!}
</div>
