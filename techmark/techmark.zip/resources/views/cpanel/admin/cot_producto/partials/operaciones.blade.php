<fieldset class="scheduler-border">
    <legend class="scheduler-border">OPERACIONES</legend>
    <div class="form-group col-lg-3">
        <span class="btn btn-inverse waves-effect waves-light  btn-sm pull-right m-t-30"  id="Search"><i class=" icon-magnifier"></i>  Producto</span>

    </div>
    <div class="form-group col-lg-3">
        <button type="submit" class="btn btn-inverse waves-effect waves-light  btn-sm pull-right m-t-30"  id="AddItemCart"><i class=" icon-basket"></i>  Agregar</button>

    </div>
    <div class="form-group col-lg-3">
        <span class="btn btn-inverse waves-effect waves-light  btn-sm pull-right m-t-30"  id="ClearItemCart"><i class=" ti-brush-alt"></i>  Limpiar</span>

    </div>
</fieldset>