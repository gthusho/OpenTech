
<div class="btn-group pull-left m-t-15">
    <a href="{{route('admin.ciudad.create')}}" class="btn btn-primary  waves-effect waves-light" >Agregar <span class="m-l-5"><i class="fa fa-plus"></i></span></a>
</div>