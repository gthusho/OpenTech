<?php

return [
    /*
     * ruta temporal para todos los archivos
    */
    'temp'=>'system/temp/',
    /*
     * ruta archivos agendas
     */
    'archivos'=>'system/archivos/',
    'trabajadores'=>'system/trabajadores/',
    'productos'=>'system/productos/',

];
